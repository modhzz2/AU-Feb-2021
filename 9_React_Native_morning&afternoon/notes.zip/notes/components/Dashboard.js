import React from 'react';

import {View, Text, TouchableOpacity, Button, ScrollView} from "react-native";
import {deleteData, getData} from "../service";
import AsyncStorage from "@react-native-community/async-storage"
import styles from './style.js';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';

class Dashboard extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            notes : getData()
        }
    }
    check = async () =>
    {
        const data = await AsyncStorage.getItem('notes');

        if(data)
        {
            this.setState({
                notes: JSON.parse(data)
            })
            console.log("beg",this.state.notes);
        }
    }
    componentDidMount()
    {
        this.check();

        this.props.navigation.addListener('focus',async () => {
          console.log('focus');
          this.setState({
              notes: getData()
          },async () =>
          {
              AsyncStorage.setItem('notes',JSON.stringify(this.state.notes));
              const data = await AsyncStorage.getItem('notes');
              if(data)
              {
                  console.log("After add",JSON.parse(data));
              }
          });

        });
    }

    render()
 {


     const notesList = this.state.notes.map((item) =>
     {
         return (
             <View key={item.id} style={styles.container}>
                 <View>
                     <Text style={styles.title}>{item.title}</Text>
                     <Text style={styles.desc}>{item.desc}</Text>
                 </View>
                 <View style={styles.btn}>
                    <TouchableOpacity onPress={() =>
                     {
                         deleteData(item);
                         this.setState({
                             notes: getData()
                         },() =>
                         {
                             AsyncStorage.setItem("notes",JSON.stringify(this.state.notes));
                         })
                     }} style={styles.appButtonContainer2}>
                        <Text style={styles.appButtonText }>Delete</Text>
                    </TouchableOpacity>
                 </View>
             </View>
         );
     })

     return (
         <View>
             <ScrollView>
                 {getData().length === 0 ? <Text>No notes in the list</Text> : notesList}
             </ScrollView>  
              <TouchableOpacity onPress={() =>
             {
                 this.props.navigation.navigate('AddNotes')
             }} style={styles.fab} >
            <FontAwesomeIcon icon={ faPlus } size={40}/>
        </TouchableOpacity>
                  
             </View>
          
     )
 }
}



export default Dashboard;