import React, {useState} from "react";
import {ScrollView, Text, TouchableOpacity, TextInput} from "react-native";
import {addData, getData} from "../service";
import styles from './style.js';

export const AddNotes = ({navigation}) =>
{
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');


    const addNotes =() =>
    {
        let id = getData().length + 1;
        for(let i = 1; i<=100; i++)
        {
            let m = getData().map((item) => item.id === id);
            if(!m)
            {
                id =i;
                break;
            }
        }
        addData({title,desc,id});
        navigation.navigate('Dashboard');
    }

    return(
        <ScrollView style={{backgroundColor:"#116466"}}>
                <TextInput onChangeText={(t)=> setTitle(t)} placeholder={'Title'} style={{...styles.textInputStyle,marginTop:130,height:45}}/>
                <TextInput onChangeText={(t) => setDesc(t)} placeholder={'Description'} multiline={true} numberOfLines={6}
                    style={{...styles.textInputStyle}}/>
                <TouchableOpacity onPress={addNotes} style={styles.appButtonContainer}>
                    <Text style={styles.appButtonText}>Add</Text>
                </TouchableOpacity>
        </ScrollView>
    )
}


