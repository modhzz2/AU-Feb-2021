import {TouchableOpacity, TextInput, View,Text,AsyncStorage} from "react-native";
import {useEffect} from "react";
import styles from './style.js';

import React, {useState} from "react";

const Login = ({navigation}) =>
{
    const [username,setUser] = useState("");
    const [err,seterr] = useState("");

    useEffect( () =>
    {
        checkAuth();
    },[])

    const logMein = () => {

        if(!username)
        {
            seterr("Please enter a valid username!!!");
            return;
        }
        seterr("");
         AsyncStorage.setItem("username",username);
        navigation.navigate("Dashboard")

        console.log(username);

    }

    const checkAuth = async () => {
        const username = await AsyncStorage.getItem("username");

        if(username)
            navigation.navigate("Dashboard");
    }

    return(
        <View style={styles.container2}>
            <Text style={styles.loginTextStyle} >Welcome to NOTES!</Text>
            <TextInput onChangeText={(text) => {setUser(text)}} style = {styles.textInputStyle2} placeholder ="Username" placeholderTextColor = "white"/>
            <Text style = {styles.errmsg}>{err}</Text>         
            <TouchableOpacity onPress={logMein} style={styles.appButtonContainer}>
                    <Text style={styles.appButtonText}>Login</Text>
            </TouchableOpacity>
        </View>
    )
};


export default Login;