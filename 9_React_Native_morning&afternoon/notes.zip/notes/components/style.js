import {StyleSheet} from 'react-native';

export default StyleSheet.create({
     textInputStyle: {
         backgroundColor: "#ffcb9a",
         borderRadius: 10,
         borderColor: "#116466",
         marginTop: 10,
        borderWidth: 2,
        fontSize: 20,
        marginLeft:75,
        padding: 10,
        width: "60%",
        height: "50%",
        marginBottom: 20,
         textAlign:'center'
    },
    topContainer:{
        marginTop: 20,
    },

    btn:{
        width: 200,
        alignSelf: 'flex-end'
    },
    title: {
        fontSize:40,
        color: "black",
        fontWeight: "700",
        padding: 5,
        fontFamily:"Cochin",
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop:'5%',
        textAlign:"center"
    },
    desc: {
        fontSize: 18,
        color: "black",
        fontWeight: "500",
        padding: 5,
        textAlign:"center"
    },
    container: {
        backgroundColor:"#009688",
        width: "95%",
        marginRight: "2.5%",
        marginLeft: "2.5%",
        borderRadius:15,
        padding: 15,
        height: 'auto',
        marginVertical: 8
                //backgroundColor: 'white'
    },
    appButtonContainer: {
        elevation: 8,
        backgroundColor: "#009688",
        borderRadius: 100,
        paddingVertical: 10,
        marginTop:"10%",
        paddingHorizontal: 12,
        width:"50%",
        alignSelf:"center"
      },
      appButtonText: {
        fontSize: 18,
        color: "#fff",
        fontWeight: "bold",
        alignSelf: "center",
        fontStyle:"italic"
      },
      appButtonContainer2: {
        elevation: 8,
        backgroundColor: "red",
        borderRadius: 100,
        paddingVertical: 10,
        marginTop:"15%",
        marginLeft:"-60%",
        paddingHorizontal: 12,
        width:"50%",
        alignSelf:"center"
      },
      
      
      
      container2: {
          backgroundColor:"#ffcb9a",
          flex: 1,
        paddingTop:"10%",
        alignItems: "center",
        textAlign:'center'
    },
    loginTextStyle: {
        fontSize: 50,
        fontWeight: "700",
        marginVertical: 20,
        paddingBottom:130
    },
    fab: { 
        position: 'absolute', 
        width: 56, 
        height: 56, 
        alignItems: 'center', 
        justifyContent: 'center', 
        right: 20, 
        bottom: 20, 
        backgroundColor: '#FFF', 
        borderRadius: 30, 
        elevation: 2,
          color: '#000' 
        }, 
    textInputStyle2: {
        backgroundColor:"#116466",
        borderRadius:100,
        fontSize: 25,
        padding: 20,
        width: "80%",
        color:"white",
        marginBottom: 20
    },



});
