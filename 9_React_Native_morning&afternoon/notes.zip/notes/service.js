let notes = [
    {
        title: 'WandaVision',
        id: 1,
        desc: 'Living idealized suburban lives, super-powered beings Wanda and Vision begin to suspect that everything is not as it seems.'
    },
    {
        title: 'Loki',
        id: 2,
        desc: 'Loki is an upcoming American television series created by Michael Waldron for the streaming service Disney+, based on the Marvel Comics character of the same name. '
    },
    {
        title: 'Agents Of Shield',
        id: 3,
        desc: 'Agent Phil Coulson leads a team of highly skilled agents from the global law-enforcement organisation known as S.H.I.E.L.D. Together, they combat extraordinary and inexplicable threats.'
    }
]

export const getData = () =>
{
    return notes;
}

export const addData = (item) =>
{
    notes = Object.assign([], notes);
    notes.push(item);
}

export const deleteData = (data) =>
{
    notes = notes.filter((item) => data.id !== item.id);
}