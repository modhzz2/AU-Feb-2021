export const  add = (item) =>
{
    return {
        type: "ADD",
        data:item
    }
}