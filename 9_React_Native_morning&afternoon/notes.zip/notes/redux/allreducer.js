import {combineReducers} from "redux";
import notes from "./reducer"


export default combineReducers({
    notes
})