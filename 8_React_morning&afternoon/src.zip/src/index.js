import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import {Route, Switch } from "react-router";
import {About, About2, About3, About4, About5, About6, About7, About8, About9, About10} from "./components/About/About.js";
import {BrowserRouter} from "react-router-dom";

ReactDOM.render((
     <BrowserRouter>
      <Switch>
          <Route exact path="/">
            <App />
          </Route>
          <Route exact path="/1">
              <About /> 
          </Route>
          <Route path="/2">
              <About2 /> 
          </Route>
          <Route path="/3">
              <About3 /> 
          </Route>
          <Route path="/4">
              <About4 /> 
          </Route>
          <Route path="/5">
              <About5 /> 
          </Route>
          <Route path="/6">
              <About6 /> 
          </Route>
          <Route path="/7">
              <About7 /> 
          </Route>
          <Route path="/8">
              <About8 />
          </Route>
          <Route path="/9">
              <About9 /> 
          </Route>
          <Route path="/10">
              <About10 /> 
          </Route>
       </Switch>
       </BrowserRouter>
), document.getElementById('root'))

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
