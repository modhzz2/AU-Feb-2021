import React from "react";
import "./About.css";
import books from "../../books.json";

 export const About = (aboutProps) => {
   return (
  <div className="CW">
  <div className="CD">
      <div><h1> {books[0].title} </h1></div>
  </div> 
   <div className="CI">
    <img className="I" src={books[0].image} alt=""/>
  </div> 
  <div className="CD">
      <div><h2> {books[0].author}</h2></div>
      <div>
      {books[0].desc}
      </div>
    </div>
</div>
);
 };


































 export const About2 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[1].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[1].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2>{books[1].author} </h2></div>
     <div>
     {books[1].desc}
     </div>
   </div>
</div>
);
};

export const About3 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[2].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[2].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[2].author}</h2></div>
     <div>
     {books[2].desc}
     </div>
   </div>
</div>
);
};

export const About4 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[3].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[3].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2>{books[3].author} </h2></div>
     <div>
     {books[3].desc}
     </div>
   </div>
</div>
);
};

export const About5 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[4].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[4].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[4].author}</h2></div>
     <div>
     {books[4].desc}
     </div>
   </div>
</div>
);
};

export const About6 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[5].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[5].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[5].author} </h2></div>
     <div>
     {books[5].desc}
     </div>
   </div>
</div>
);
};

export const About7 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[6].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[6].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[6].author} </h2></div>
     <div>
     {books[6].desc}
     </div>
   </div>
</div>
);
};

export const About8 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[7].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[7].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[7].author}</h2></div>
     <div>
     {books[7].desc}
     </div>
   </div>
</div>
);
};

export const About9 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[8].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[8].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2> {books[8].author}</h2></div>
     <div>
     {books[8].desc}
     </div>
   </div>
</div>
);
};

export const About10 = (aboutProps) => {
  return (
 <div className="CW">
 <div className="CD">
     <div><h1> {books[9].title} </h1></div>
 </div> 
  <div className="CI">
   <img className="I" src={books[9].image} alt=""/>
 </div> 
 <div className="CD">
     <div><h2>{books[9].author} </h2></div>
     <div>
     {books[9].desc}
     </div>
   </div>
</div>
);
};










