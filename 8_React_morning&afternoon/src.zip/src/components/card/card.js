import React from "react";
import PropTypes from "prop-types";
import {Link} from "react-router-dom";
import "./card.css"

const Card = (props) => {
  return (
    <div className="CardWrapper">
      <div className="ColImg">
        <img className="Img" src={props.image} alt={props.title} />
      </div>
      <div className="ColDetail">
        <div className="Header">
          <div className="BookTitle">{props.title}</div>
        </div>
        <div className="BookAuthor">{props.author}</div>
        <Link to ={`/${props.id}`}> Learn more </Link>
      </div>
    </div>
  );
};

Card.propTypes = {
  image: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
};

export default Card;