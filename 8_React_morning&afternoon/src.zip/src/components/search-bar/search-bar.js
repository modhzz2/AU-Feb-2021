import React from "react";
import PropTypes from "prop-types";
import "./search-bar.css";

const SearchBar = (props) => {
  return (
    <div className="Search">
      <span className="SearchSpan">
      
      </span>
      <input
        className="SearchInput"
        type="text"
        onChange={props.onChange}
        placeholder={props.placeholder}
      />
    </div>
  );
};

SearchBar.propTypes = {
  onChange: PropTypes.func.isRequired,
  placeholder: PropTypes.string.isRequired,
};

export default SearchBar;